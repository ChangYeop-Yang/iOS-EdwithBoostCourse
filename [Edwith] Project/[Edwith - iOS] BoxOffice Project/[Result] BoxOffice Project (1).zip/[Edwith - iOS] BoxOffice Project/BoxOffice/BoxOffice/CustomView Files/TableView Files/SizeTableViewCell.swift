//
//  SizeTableViewCell.swift
//  BoxOffice
//
//  Created by 양창엽 on 23/06/2019.
//  Copyright © 2019 양창엽. All rights reserved.
//

import UIKit

internal enum SizeCellHeight: CGFloat {
    case movie      = 115
    case comment    = 90
}
