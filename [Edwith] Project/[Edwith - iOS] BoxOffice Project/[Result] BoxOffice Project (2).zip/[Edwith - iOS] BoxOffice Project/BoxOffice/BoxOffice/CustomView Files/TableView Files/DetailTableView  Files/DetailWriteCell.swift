//
//  DetailWriteCell.swift
//  BoxOffice
//
//  Created by 양창엽 on 09/07/2019.
//  Copyright © 2019 양창엽. All rights reserved.
//

import UIKit

class DetailWriteCell: UITableViewCell {}
