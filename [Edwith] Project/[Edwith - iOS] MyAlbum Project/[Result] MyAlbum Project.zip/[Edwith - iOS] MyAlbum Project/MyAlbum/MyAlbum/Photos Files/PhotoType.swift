//
//  PhotoType.swift
//  MyAlbum
//
//  Created by 양창엽 on 21/05/2019.
//  Copyright © 2019 양창엽. All rights reserved.
//

import Photos

// MARK: - Typealias
internal typealias PHResult = (title: String, asset: PHFetchResult<PHAsset>)
