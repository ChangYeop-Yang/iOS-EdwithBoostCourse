//
//  TagTextField.swift
//  SignUp
//
//  Created by 양창엽 on 16/04/2019.
//  Copyright © 2019 양창엽. All rights reserved.
//

import Foundation

internal enum TagTextField: Int {
    case UserID = 100
    case UserPassword = 200
}
